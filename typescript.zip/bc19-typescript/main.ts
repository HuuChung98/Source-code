// Bởi vì browser không thể run được code typescript
// Ta cần compile TS sang JS
// Window/Linux: Ctrl + Shift + B
// Mac: Cmd + Shift + B

console.log("Hello Typescript - BC19");

// ============== 1. Typed ==============
let a = 5;
let b: number;
// a = 'Năm' // Type 'string' is not assignable to type 'number'
b = 10;
// b = 'Mười' // Type 'string' is not assignable to type 'number'

// let message: string
let message = "Hello BC19";
// message = "Hello BC19"
// message = { value: "Hello BC19" };

let isLoggedIn = false;
isLoggedIn = true;
// isLoggedIn = 'true'

let n: null = null;
let u: undefined = undefined;

// - Array
// let alphabets: string[];
// alphabets = ["a", "b", "c", "d", "e"];
let alphabets = ["a", "b", "c", "d", "e"];

// - Tuple
let tuple: [string, number];
tuple = ["score", 8];
// tuple = [8, 'score']

// - Enum
enum Color {
  black = "#000",
  white = "#fff",
  red = "#f00",
}
console.log(Color.black); // #000
// Các giá trị của enum là read-only (chỉ được đọc mà k được thay đổi)
// Color.black = "#333"

// - function name(...params: ...ParamsType): ReturnType
function sum(a: number, b: number): number {
  return a + b;
}
sum(2, 3); // 5
// sum("2", "3"); // Error

// Đối với hàm không có có return thì kiểu dữ liệu của hàm sẽ là void
function showMessage(): void {
  let name = prompt("Input your name");
  alert(`Hello ${name}`);
}

// - Custom Type cho object: dùng từ khoá type hoặc interface
// type Student = {
//   name: string;
//   email: string;
//   age?: number;
//   className?: string;
// };

interface Student {
  name: string;
  email: string;
  age?: number;
  className?: string;
}

const student1: Student = {
  name: "Dan",
  email: "dan@gmail.com",
  age: 26,
  // className: "BC19",
};

const student2: Student = {
  name: "Quan",
  email: "quan@gmail.com",
  className: "BC19",
};

// Union Types: | (OR)
function printId(id: number | string): void {
  console.log("Your ID is: " + id);
}
printId(1234);
printId("0001");

// Tạo biến result để lấy data từ API
let result: Student | null = null;
setTimeout(() => {
  result = {
    name: "Khải",
    email: "khai@gmail.com",
  };
}, 3000);

// Dùng Record để tạo một object chưa xác định được các giá trị key và value
const todo: Record<string, unknown> = {
  title: "Do homework",
  isCompleted: false,
};

todo.description = "React capstone project";

// Tạo Custom Type Todo
interface Todo {
  title: string;
  description: string;
  completed: boolean;
}

// Pick: Từ type ban đầu, chọn một số thuộc tính và tạo ra type mới
// Ví dụ: Khi tạo mới 1 todo, ta chỉ cần truyền title và description còn completed mặc định sẽ được server tạo ra là false
type TodoCreate = Pick<Todo, "title" | "description">;

const createdTodo: TodoCreate = {
  title: "Homework",
  description: "Homework.......",
};

// =============== 2. Interfaces ===============
// class Employee {
//   id: number;
//   firstName: string;
//   lastName: string;
//   email: string;

//   constructor(id: number, firstName: string, lastName: string, email: string) {
//     this.id = id;
//     this.firstName = firstName;
//     this.lastName = lastName;
//     this.email = email;
//   }

//   calcSalary(): number {
//     return 1000;
//   }
// }

// class Manager extends Employee {
//   coefficientsSalary: number;

//   constructor(
//     id: number,
//     firstName: string,
//     lastName: string,
//     email: string,
//     coefficientsSalary: number
//   ) {
//     super(id, firstName, lastName, email);
//     this.coefficientsSalary = coefficientsSalary;
//   }

//   calcSalary(): number {
//     return super.calcSalary() * this.coefficientsSalary;
//   }
// }

// const manager = new Manager(1, "A", "B", "a@gmail.com", 3);
// const salary = manager.calcSalary();

interface Employee {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  coefficientsSalary: number;
  calcSalary(): number;
}

interface Manager {
  department: string;
  responsibility: string[];
}

interface Engineer {
  languages: string[];
}

class ProjectManager implements Employee, Manager {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  coefficientsSalary: number;
  department: string;
  responsibility: string[];

  constructor(
    id: number,
    firstName: string,
    lastName: string,
    email: string,
    coefficientsSalary: number,
    department: string,
    responsibility: string[]
  ) {
    this.id = id;
    this.firstName = firstName;
    this.lastName = lastName;
    this.email = email;
    this.coefficientsSalary = coefficientsSalary;
    this.department = department;
    this.responsibility = responsibility;
  }

  calcSalary(): number {
    return 1000 * this.coefficientsSalary;
  }
}

class FrontendEngineer implements Employee, Engineer {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  coefficientsSalary: number;
  languages: string[];

  constructor(
    id: number,
    firstName: string,
    lastName: string,
    email: string,
    coefficientsSalary: number,
    languages: string[]
  ) {
    this.id = id;
    this.firstName = firstName;
    this.lastName = lastName;
    this.email = email;
    this.coefficientsSalary = coefficientsSalary;
    this.languages = languages;
  }

  calcSalary(): number {
    return 1000 * this.coefficientsSalary;
  }
}

// ============= 3. Generic ================

// Không thể xác định kiểu dữ liệu trả về của hàm tại thời điểm định nghĩa hàm
// Để xử lý trường hợp này ta dùng kĩ thuật generic
// - Cho phép định nghĩa 1 type variable, và kiểu dữ liệu của type này sẽ được xác định tại thời điểm gọi hàm
async function getAPI<T>(
  url: string,
  options: Record<string, unknown> = {}
): Promise<T> {
  const response = await fetch(url, options);
  const data = await response.json();
  return data;
}

interface Product {
  name: string;
  price: string;
  image: string;
  description: string;
  id: string;
}
getAPI<Product>(
  "https://629757b414e756fe3b2dc8f0.mockapi.io/api/products/1"
).then((result) => {
  console.log("Product:", result);
});

getAPI<Product[]>(
  "https://629757b414e756fe3b2dc8f0.mockapi.io/api/products"
).then((result) => {
  console.log("Product List:", result);
});

// DOM: Khi DOM tới 1 element nào đó, ta dùng các interface về HTML do TS cung cấp sẵn, nó sẽ giúp ta nhắc lệnh những phương thưc và thuộc tính hợp lệ của một loại element cụ thể
const emailEl = <HTMLInputElement>document.getElementById("txtEmail");
emailEl.value;
const submitEl = <HTMLButtonElement>document.getElementById("btnSubmit");
submitEl.addEventListener("click", () => {});












