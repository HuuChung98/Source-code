### Tổng quan

- Angular, React, Vue là các thư viện và framework giúp xây dựng trang web theo hướng Single page application
Tham khảo: https://toidicodedao.com/2018/09/11/su-khac-biet-giua-server-side-rendering-va-client-side-rendering


### React:

- https://reactjs.org/
- Là một thư viện javascript dùng để xây dựng giao diện người dùng
- VSCode extensions:
  - https://marketplace.visualstudio.com/items?itemName=dsznajder.es7-react-js-snippets
  - https://marketplace.visualstudio.com/items?itemName=riazxrazor.html-to-jsx
- Browser extensions:
  - https://chrome.google.com/webstore/detail/react-developer-tools/fmkadmapgofadopljbjfkapdkoienihi?hl=en

### Create react app:

- Câu lệnh: npx create-react-app <project-name>
- CRA cung cấp bộ công cụ khởi tạo ứng dụng React, vì vậy bạn có thể đi vào xây dựng ứng dụng của mình mà không cần phải xử lý các cấu hình Webpack và Babel.

### Component:

- Components giúp phân chia các UI (giao diện người dùng) thành các phần nhỏ để dễ dàng quản lý và tái sử dụng.
- Về cơ bản, component cũng giống một javascript function return về những phần tử React mô tả những gì sẽ xuất hiện trên giao diện.
- Luôn luôn bắt đầu component name với chữ cái in hoa React sẽ coi những component bắt đầu với chữ cái in thường là DOM tags. Ví dụ, `<div />` đại diện cho 1 thẻ div HTML, nhưng `<Welcome />` đại diện cho 1 component
- Có 2 loại component
  - Function component (nên sử dụng)
  ```
  function App() {
    return (
      <div>
        Hello World!!!
      </div>
    );
  }
  ```
  - Class component
  ```
  class App extends React.Component {
    render() {
      return (
        <div>
          Hello World!!!
        </div>
      );
    }
  }
  ```

### JSX:

- JSX = Javascript + XML
- React sử dụng JSX để biểu thị UI components
- JSX cho phép viết các phần tử HTML bằng JavaScript và đặt chúng trong DOM mà không cần bất kỳ phương thức như createElement() hoặc appendChild().
- Cú pháp JSX:
```
const title = "BC19 - React"
const jsx = (
  <section className="app">
    <h1>{title}</h1>
  </section>
)
```

- Code JSX nếu được viết bằng JS thuần
```
const title = "BC19 - React";
const jsx = React.createElement("section", {
  className: "app"
}, React.createElement("h1", null, title));
```
- Vì JSX gần với JavaScript hơn là so với HTML, React sử dụng chuẩn quy tắc đặt tên camelCase cho thuộc tính thay vì dùng tên thuộc tính gốc của HTML.
  - className thay cho class
  - htmlFor thay cho for
  - tabIndex thay cho tabindex
  - ...


### Style:

- Sử dụng bằng cách import vào component, Eg: import './style.css'. Tuy nhiên cách import này có 1 nhược điểm là tuy ta chỉ import vào 1 component nhưng tất cả component khác đều hiểu class trong file css này
- Sử dụng css module, Eg: import style from './style.module.css', `<div className={style.title}></div>`. Sử dụng cách này thì chỉ những component nào import file css này thì mới có thể sử dụng class trong file css
- Sử dụng scss bằng cách cài đặt thư viện sass: npm install -D sass


### Props:
- Props là một object được truyền vào trong một components, mỗi components sẽ nhận vào props và trả về react element.
- Props cho phép chúng ta giao tiếp giữa các components với nhau bằng cách truyền tham số qua lại giữa các components.
- Cách truyền một props cũng giống như cách mà bạn thêm một attributes cho một element HTML.
```
// Truyền props cho component Welcome
<Welcome name="Jack" age={18} />
```
```
// Nhận giá trị của props trong class component bằng this.props
import React, { Component } from "react";
class Welcome extends Component {
  render() {
    console.log(this.props) //Giá trị của props
    return (
      <div>
        <h1>Xin chào {this.props.name} !</h1>
      </div>
    );
  }
}
export default Welcome;
```
```
// Nhận props trong functional components bằng params
import React from "react";
const Welcome = (props) => {
  console.log(props) //Giá trị của props
  return (
    <div>
      <h1>Xin chào {props.name} !</h1>
    </div>
  );
};
export default Welcome;
```
- Khi components cha truyền cho component con một props thì components con chỉ có thể đọc và không có quyền chỉnh sửa nó
- Mỗi khi dữ liệu trong props thay đổi thì component đó sẽ được render lại.


### State
- State là một object có thể được sử dụng để chứa dữ liệu hoặc thông tin về components. State có thể được thay đổi bất cứ khi nào mong muốn. Khác với props bạn có thể truyền props sang các components khác nhau thì state chỉ tồn tại trong phạm vi của components chứa nó, mỗi khi state thay đổi thì components đó sẽ được render lại.
- Trong các dự án React, state được dùng để phản hồi các yêu cầu từ người dùng, hay lưu trữ một dữ liệu nào đó trong components.
```
// Tạo state trong constructor
import React from "react";

class App extends React.Component {
  constructor(props) {
    super(props);
    // Tạo state
    this.state = {
      message: "Cybersoft Academy"
    };
  }
  render() {
    return (
      <div>
        <h1>Hello {this.state.message}</h1>
      </div>
    );
  }
}
export default App;
```
- Mỗi khi state thay đổi thì component sẽ được re-render.
- Để cập nhật state ta không thay đổi trực tiếp state mà phải thông qua hàm this.setState
- Wrong: this.state.message = 'Hello';
- Correct: this.setState({ message: 'Hello' });
- Lưu ý: setState là hàm bất đồng bộ, nếu cần lấy kết qua sau khi setState ta sẽ lấy trong tham số thứ 2 của hàm setState là 1 callback function
```
this.setState({message: 'Hello'}, () => { console.log(this.state.message) })
```

### Sự khác nhau giữa props và state

- State - Dữ liệu chỉ nằm trong phạm vi của một component và không thể sử dụng ở những component khác.
- Props - Dữ liệu đường truyền từ component cha cho componet con, components con khi nhận được sẽ chỉ được đọc mà không thể thay đổi dữ liệu đó.
- Tuy nhiên khi state hoặc props thay đổi đều làm cho component re-render.


### Lifecycle

https://projects.wojtekmaj.pl/react-lifecycle-methods-diagram/


