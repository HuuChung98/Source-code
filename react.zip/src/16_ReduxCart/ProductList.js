import React from "react";
import { useSelector } from "react-redux";
import ProductItem from "./ProductItem";

const ProductList = () => {
  const { products } = useSelector((state) => state.cart);

  return (
    <div className="row">
      {products.map((product) => (
        <div key={product.id} className="col-sm-4">
          <ProductItem product={product} />
        </div>
      ))}
    </div>
  );
};

export default ProductList;
