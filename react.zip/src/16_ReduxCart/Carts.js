import React from "react";
import { useSelector, useDispatch } from "react-redux";

const Carts = () => {
  const { carts } = useSelector((state) => state.cart);
  const dispatch = useDispatch();

  const increase = (productId) => {
    // productId là id của sản phẩm muốn tăng
    // gửi 1 action lên redux store yêu cầu tăng số lượng sản phẩm
    dispatch({
      type: "INCREASE_QUANTITY",
      data: productId,
    });
  };

  const decrease = (productId) => {
    // gửi 1 action lên redux store yêu cầu giảm số lượng sản phẩm
    dispatch({
      type: "DECREASE_QUANTITY",
      data: productId,
    });
  };

  const remove = (productId) => {
    // gửi 1 action lên redux store yêu cầu xoá sản phẩm trong giỏ hàng
    dispatch({
      type: "REMOVE_PRODUCT",
      data: productId,
    });
  };

  return (
    <table className="table">
      <thead>
        <tr>
          <th>Image</th>
          <th>Name</th>
          <th>Price</th>
          <th>Quantity</th>
          <th>Total</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        {carts.map((item) => (
          <tr key={item.id}>
            <td>
              <img
                src={item.image}
                alt={item.name}
                width="50px"
                height="50px"
              />
            </td>
            <td>{item.name}</td>
            <td>{item.price}</td>
            <td>
              <button
                className="btn btn-danger"
                onClick={() => decrease(item.id)}
              >
                -
              </button>
              <span className="mx-2">{item.quantity}</span>
              <button
                className="btn btn-success"
                onClick={() => increase(item.id)}
              >
                +
              </button>
            </td>
            <td>{item.quantity * item.price}</td>
            <td>
              <button
                className="btn btn-danger"
                onClick={() => remove(item.id)}
              >
                X
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default Carts;
