import React from "react";
import Carts from "./Carts";
import ProductList from "./ProductList";

const ReduxCart = () => {
  return (
    <div className="container">
      <h1 className="text-center">Product Carts</h1>

      <Carts />

      <ProductList />
    </div>
  );
};

export default ReduxCart;
