// Component chứa các component con của layout msi
import React from "react";
import Header from "./Header";
import Slider from "./Slider";
import ProductList from "./ProductList";
import Footer from "./Footer";

function LayoutMSI() {
  return (
    <div className="bg-dark">
      <Header />
      <Slider />
      <ProductList />
      <Footer />
    </div>
  );
}

export default LayoutMSI;
