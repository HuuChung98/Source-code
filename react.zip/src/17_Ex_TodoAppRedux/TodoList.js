import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import TodoItem from "./TodoItem";
import { getTodos } from "../redux/slices/todo";

export default function TodoList() {
  const dispatch = useDispatch();
  const { todos, search, filter, isLoading, error } = useSelector(
    (state) => state.todo
  );

  // const fetchTodos = async () => {
  //   try {
  //     // Call API
  //     const { data } = await axios.get(
  //       "https://625a732843fda1299a17d4e6.mockapi.io/api/todos"
  //     );
  //     // Thành công
  //     dispatch({ type: "GET_TODOS", data });
  //   } catch (error) {
  //     console.log(error);
  //   }
  // };

  useEffect(() => {
    // Gọi trực tiếp tới function gọi API trong component
    // Nhược điểm là function gọi API không thể tái sử dụng được
    // fetchTodos();

    // dispatch 1 async action nhờ sử dụng redux-thunk
    // trong action này sẽ thực hiện việc gọi API và sau đó dispatch tiếp 1 action mới lên store để cập nhật state
    dispatch(getTodos());
  }, [search, filter]);

  if (isLoading) {
    // return <Loading />
    return <h1>Loading...</h1>;
  }

  if (error) {
    // return <ErrorMessage error={error} />
    return <div className="alert alert-danger">{error}</div>;
  }

  return (
    <ul className="p-0">
      {todos.map((todo) => {
        return <TodoItem key={todo.id} todo={todo} />;
      })}
    </ul>
  );
}
