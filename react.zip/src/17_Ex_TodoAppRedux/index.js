import React from "react";
import AddTodo from "./AddTodo";
import FilterTodo from "./FilterTodo";
import SearchTodo from "./SearchTodo";
import TodoList from "./TodoList";

export default function TodoAppRedux() {
  return (
    <div className="container">
      <div className="row">
        <div className="col-sm-6 mx-auto">
          <h1 className="text-center text-secondary">My Todos</h1>
          <AddTodo />
          <SearchTodo />
          <TodoList />
          <FilterTodo />
        </div>
      </div>
    </div>
  );
}
