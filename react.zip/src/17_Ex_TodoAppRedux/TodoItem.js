import React from "react";
import { useDispatch } from "react-redux";
import cn from "classnames";
import styles from "./styles.module.scss";
import { completeTodo, deleteTodo } from "../redux/actions/todo";

export default function TodoItem({ todo }) {
  const dispatch = useDispatch();
  // Thay vì gọi API trực tiếp trong component và gửi thông báo cho component cha để gọi lại API get todos, ta chỉ cần dispatch 1 async action
  const handleDeleteTodo = () => {
    dispatch(deleteTodo(todo.id));
  };

  const handleCompleteTodo = () => {
    dispatch(completeTodo(todo));
  };

  return (
    <li className="d-flex justify-content-between align-items-center mb-4">
      <div
        className={cn("d-flex flex-column", {
          [styles.todoCompleted]: todo.isCompleted,
        })}
      >
        <span>{todo.title}</span>
        <i>{todo.description}</i>
      </div>

      <div>
        <button
          className={cn("btn btn-success mr-2", {
            [styles.btnCompleted]: todo.isCompleted,
          })}
          onClick={handleCompleteTodo}
        >
          Complete
        </button>
        <button className="btn btn-danger" onClick={handleDeleteTodo}>
          Delete
        </button>
      </div>
    </li>
  );
}
