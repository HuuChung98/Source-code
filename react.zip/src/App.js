// import FunctionComponent from './1_Components/FunctionComponent'
// import ClassComponent from './1_Components/ClassComponent'
import LayoutMSI from "./2_LayoutMSI";
// import Props from './3_Props'
// import State from './4_State'
// import HandlingEvent from './5_HandlingEvent'
// import ConditionalRendering from './6_ConditionalRendering'
// import ExChangeCar from "./7_Ex_Car";
// import Map from "./8_Map";
// import ProductCart from "./9_Ex_ProductCart";
// import Composition from "./10_Composition";
// import UserManagement from "./11_Ex_UserManagement";
// import Lifecycle from "./12_Lifecycle";
// import DemoUseEffect from "./13_Hooks/DemoUseEffect";
// import DemoUseState from "./13_Hooks/DemoUseState";
import DemoUseRef from "./13_Hooks/DemoUseRef";
import TodoApp from "./14_Ex_TodoApp";
import DemoRedux from "./15_Redux";
import ReduxCart from "./16_ReduxCart";
import TodoAppRedux from "./17_Ex_TodoAppRedux";

import { Routes, Route, Link } from "react-router-dom";
import MovieList from "./18_Router/MovieList";
import MovieDetails from "./18_Router/MovieDetails";
import MovieLayout from "./18_Router/MovieLayout";

function App() {
  return (
    <>
      {/* Điều hướng url */}
      <Link to="/">Home</Link>
      <Link to="/todo-app">Todo App</Link>
      <Link to="/todo-app-redux">Todo App Redux</Link>
      <Link to="/demo-redux">Demo Redux</Link>

      {/* Cấu hình để react router render ra component tương ứng với URL */}
      <Routes>
        {/* Nếu url là localhost:3000 => Sẽ render ra component LayoutMSI */}
        <Route path="/" element={<LayoutMSI />} />
        <Route path="/todo-app" element={<TodoApp />} />
        <Route path="/todo-app-redux" element={<TodoAppRedux />} />
        <Route path="/demo-redux" element={<DemoRedux />} />

        {/* Nested Routes */}
        {/* Khi muốn 1 hoặc nhiều Route có cùng 1 layout, ta sẽ dùng kĩ thuật nested routes */}
        {/* Route cha thường sẽ render ra 1 layout component */}
        {/* Bên trong component layout sẽ tiếp tục render ra các child route */}
        {/* Vị trí mà component MovieList hoặc MovieDetails render ra sẽ là nơi mà bên trong MovieLayout đặt component Outlet */}
        <Route path="/movies" element={<MovieLayout />}>
          {/* path: /movies */}
          <Route index element={<MovieList />} />
          {/* path: /movies/:movieId */}
          {/* path params: dynamic url */}
          <Route path=":movieId" element={<MovieDetails />} />
        </Route>

        {/* Khi không có bất kì path nào khớp với url sẽ render ra component NotFound, path="*" khớp với mọi url  */}
        <Route path="*" element={<h1>Not found</h1>} />
      </Routes>
    </>
  );
}

export default App;

// Component
// function App() {
//   // JSX: Javascript XML
//   // Cho phép viết javascript chung với html
//   // const title = "BC19 - App Root"
//   return (
//     // Demo JSX
//     // <div className="App">
//     //   <h1>{title}</h1>
//     //   {/* Gọi component bên trong 1 component */}
//     //   <FunctionComponent />
//     //   <ClassComponent />
//     // </div>

//     // Lý thuyết
//     // <Props />
//     // <State />
//     // <HandlingEvent />
//     // <ConditionalRendering />
//     // <Map />
//     // <Composition />
//     // <Lifecycle />
//     // <DemoUseState />
//     // <DemoUseEffect />
//     // <DemoUseRef />
//     // <DemoRedux />

//     // Bài tập
//     // <LayoutMSI />
//     // <ExChangeCar />
//     // <ProductCart />
//     // <UserManagement />
//     // <TodoApp />
//     // <ReduxCart />
//     // <TodoAppRedux />
//   );
// }
