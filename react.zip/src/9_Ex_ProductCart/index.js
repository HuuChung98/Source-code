import React, { Component } from "react";
import Cart from "./Cart";
import ProductDetails from "./ProductDetails";
import ProductList from "./ProductList";

class ProductCart extends Component {
  constructor() {
    super();

    this.state = {
      // Danh sách sản phẩm
      products: [
        {
          id: 1,
          name: "Iphone 13",
          display:
            "Super Retina XDR OLED, 120Hz, 6.7 inches, 1284 x 2778 pixels",
          os: "iOS 15",
          camera:
            "12 MP, f/1.5, 26mm (wide), 1.9µm, dual pixel PDAF, sensor-shift OIS",
          memory: "6GB 256GB",
          price: 31000000,
          image:
            "https://cdn.tgdd.vn/Products/Images/42/223602/iphone-13-midnight-2-600x600.jpg",
        },
        {
          id: 2,
          name: "Samsung galaxy S22 Ultra",
          display: "Dynamic AMOLED 2X, 120Hz, 6.1 inches, 1080 x 2340 pixels",
          os: "Android 12, One UI 4.1",
          camera:
            "50 MP, f/1.8, 23mm (wide), 1/1.56, 1.0µm, Dual Pixel PDAF, OIS",
          memory: "12GB 256GB",
          rom: "128 GB",
          price: 32000000,
          image:
            "https://cdn.tgdd.vn/Files/2021/12/06/1402535/galaxys22ultra_3_1280x720-800-resize.jpg",
        },
        {
          id: 3,
          name: "Oppo Find X5 Pro",
          display: "LTPO2 AMOLED, 120 Hz, 6.7 inches, 1440 x 3216 pixels",
          os: "Android 12, ColorOS 12.1",
          camera:
            "50 MP, f/1.7, 25mm (wide), 1/1.56, 1.0µm, multi-directional PDAF, OIS (3-axis sensor-shift, 2-axis lens-shift)",
          memory: "12GB 256GB",
          price: 34000000,
          image:
            "https://cdn.pocket-lint.com/r/s/1200x/assets/images/159952-phones-news-oppo-find-x5-pro-renders-image1-p8ufbrezxs.jpg",
        },
      ],

      // Danh sách sản phẩm trong giỏ hàng
      carts: [],

      // Sản phẩm đang được chọn để xem chi tiết
      selectedProduct: null,
    };
  }

  // Cài đặt 1 function callback ở component cha và truyền xuống component con thông qua props
  handleSelect = (product) => {
    // product là data từ component con truyền lên
    console.log(product);
    // setState selectedProduct bằng giá trị product vừa nhận được.
    this.setState({
      selectedProduct: product,
    });
  };

  handleAddToCart = (product) => {
    // Kiểm tra xem sản phẩm có tồn tại trong giỏ hàng chưa
    const isExisted =
      this.state.carts.findIndex((item) => item.id === product.id) !== -1;

    if (isExisted) {
      // Sản phẩm đã tồn tại
      const carts = this.state.carts.map((item) => {
        if (item.id === product.id) {
          return { ...item, quantity: item.quantity + 1 };
        }
        return item;
      });
      this.setState({ carts });
    } else {
      // Sản phẩm chưa tồn tại
      const carts = [...this.state.carts, { ...product, quantity: 1 }];
      this.setState({ carts });
    }

    // Khi thay đổi state là 1 array hoặc object, ta cần phải sao chép giá trị ra 1 array hoặc object mới và gán lại trong hàm setState
  };

  handleChangeQuantity = (product, type) => {
    const item = this.state.carts.find((item) => item.id === product.id);

    // Kiểm tra trường hợp nếu quantity bằng 1 type là decrease => xoá sản phẩm khỏi giỏ hàng
    if (item.quantity === 1 && type === "decrease") {
      const carts = this.state.carts.filter((item) => item.id !== product.id);
      this.setState({ carts });
      return;
    }

    const carts = this.state.carts.map((item) => {
      if (item.id === product.id) {
        const quantity =
          type === "increase" ? item.quantity + 1 : item.quantity - 1;
        return { ...item, quantity };
      }
      return item;
    });
    this.setState({ carts });
  };

  handleRemoveCartItem = (productId) => {
    const carts = this.state.carts.filter((item) => item.id !== productId);
    this.setState({ carts });
  };

  render() {
    return (
      <div className="container">
        <div className="d-flex justify-content-between align-items-center">
          <h1>Danh sách sản phẩm</h1>
          {/* Giỏ hàng */}
          <Cart
            carts={this.state.carts}
            onChangeQuantity={this.handleChangeQuantity}
            onRemoveCardItem={this.handleRemoveCartItem}
          />
        </div>

        {/* Danh sách sản phẩm */}
        <ProductList
          products={this.state.products}
          onSelect={this.handleSelect}
          onAddToCart={this.handleAddToCart}
        />

        {/* Chi tiết sản phẩm */}
        <ProductDetails product={this.state.selectedProduct} />
      </div>
    );
  }
}

export default ProductCart;
