import React, { Component } from "react";
import ProductItem from "./ProductItem";

class ProductList extends Component {
  render() {
    const { products, onSelect, onAddToCart } = this.props;
    return (
      <div className="row">
        {products.map((product) => {
          return (
            <div key={product.id} className="col-sm-4">
              <ProductItem
                product={product}
                onSelect={onSelect}
                onAddToCart={onAddToCart}
              />
            </div>
          );
        })}
      </div>
    );
  }
}

export default ProductList;
