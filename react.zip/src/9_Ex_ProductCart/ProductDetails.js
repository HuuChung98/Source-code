import React, { Component } from "react";

class ProductDetails extends Component {
  render() {
    const { product } = this.props;

    // Nếu không có product => không cần render ra UI
    if (!product) {
      return null;
    }

    return (
      <div className="row">
        <div className="col-sm-4">
          <h3>{product.name}</h3>
          <img
            src={product.image}
            alt={product.name}
            width="100%"
            height="400px"
          />
        </div>
        <div className="col-sm-8">
          <h2>Thông số kĩ thuật</h2>
          <table className="table">
            <tbody>
              <tr>
                <td>Màn hình</td>
                <td>{product.display}</td>
              </tr>
              <tr>
                <td>Hệ điều hành</td>
                <td>{product.os}</td>
              </tr>
              <tr>
                <td>Camera</td>
                <td>{product.camera}</td>
              </tr>
              <tr>
                <td>Memory</td>
                <td>{product.memory}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default ProductDetails;
