import React, { Component } from "react";

class Cart extends Component {
  render() {
    const { carts, onChangeQuantity, onRemoveCardItem } = this.props;

    return (
      <div>
        <button
          type="button"
          className="btn btn-primary"
          data-toggle="modal"
          data-target="#cart"
        >
          Cart
        </button>

        <div
          className="modal fade"
          id="cart"
          tabIndex={-1}
          role="dialog"
          aria-labelledby="exampleModalLabel"
          aria-hidden="true"
        >
          <div className="modal-dialog modal-lg" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title" id="exampleModalLabel">
                  Product Cart
                </h5>
                <button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  aria-label="Close"
                >
                  <span aria-hidden="true">×</span>
                </button>
              </div>
              <div className="modal-body">
                <table className="table">
                  <thead>
                    <tr>
                      <th>No.</th>
                      <th>Image</th>
                      <th>Name</th>
                      <th>Quantity</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {carts.map((item, index) => (
                      <tr key={item.id}>
                        <td>{index + 1}</td>
                        <td>
                          <img
                            src={item.image}
                            alt={item.name}
                            width="80px"
                            height="80px"
                          />
                        </td>
                        <td>{item.name}</td>
                        <td>
                          <button
                            className="btn btn-light"
                            // disabled={item.quantity === 1}
                            onClick={() => onChangeQuantity(item, "decrease")}
                          >
                            -
                          </button>
                          <span className="mx-1">{item.quantity}</span>
                          <button
                            className="btn btn-light"
                            onClick={() => onChangeQuantity(item, "increase")}
                          >
                            +
                          </button>
                        </td>
                        <td>
                          <button
                            className="btn btn-danger"
                            onClick={() => onRemoveCardItem(item.id)}
                          >
                            X
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Cart;
