import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { addColor, removeColor } from "../redux/slices/color";

const Color = () => {
  // useSelector nhận vào 1 callback có params là state tổng của store, nếu muốn truy cập vào một reducer con ta return về state chấm tới tên của reducer khai báo trong rootReducer
  const { colors } = useSelector((state) => state.color);
  const dispatch = useDispatch();

  const handleAddColor = () => {
    const color = prompt("Add color:");
    // dispatch({ type: "ADD_COLOR", data: color });
    dispatch(addColor(color));
  };

  const handleRemoveColor = () => {
    const color = prompt("Remove color:");
    // dispatch({ type: "REMOVE_COLOR", data: color });
    dispatch(removeColor(color));
  };

  return (
    <div>
      <p>Colors: {colors.join(", ")}</p>
      <button onClick={handleAddColor}>Add Color</button>
      <button onClick={handleRemoveColor}>Remove Color</button>
    </div>
  );
};

export default Color;
