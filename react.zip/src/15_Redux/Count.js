import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { increase, decrease } from "../redux/slices/count";

const Count = () => {
  // Dùng hook useSelector để kết nối tới redux store và lấy state về sử dụng trong component
  const count = useSelector((state) => state.count);
  // Dùng hook useDispatch để gửi một action thay đổi state lên redux store
  const dispatch = useDispatch();

  const handleIncrease = () => {
    // dispatch là phương thức để gửi action lên redux store
    // action là 1 object, bắt buộc có 1 key là type để mô tả action
    // const action = { type: "INCREASE" };
    // dispatch(action);

    // action được tạo ra từ createSlice của redux toolkit
    dispatch(increase());
  };

  return (
    <div>
      <p>Count: {count}</p>
      <button onClick={handleIncrease}>Increase</button>
      {/* <button onClick={() => dispatch({ type: "DECREASE" })}>Decrease</button> */}
      <button onClick={() => dispatch(decrease())}>Decrease</button>
    </div>
  );
};
export default Count;
