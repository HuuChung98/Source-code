import React from "react";
import Color from "./Color";
import Count from "./Count";

const DemoRedux = () => {
  return (
    <div>
      <h1>Count</h1>
      <Count />

      <h1>Color</h1>
      <Color />
    </div>
  );
};

export default DemoRedux;
