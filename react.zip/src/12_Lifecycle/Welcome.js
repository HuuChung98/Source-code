import React, { Component, PureComponent } from "react";

// PureComponent sẽ tự động thực thi shouldComponentUpdate
// Tự động kiểm tra props cũ và props hiện tại có khác nhau hay không, nếu khác mới re-render, ngược lại thì không cần re-render

// PureComponent khi so sánh props cũ và mới sẽ so sánh bằng shallow compare (===)
// Khi so sánh array, object, function nó sẽ so sánh địa chỉ vùng nhớ

// class Welcome extends Component {
class Welcome extends PureComponent {
  // shouldComponentUpdate được gọi khi props hoặc state thay đổi và được chạy trước hàm render
  // Nếu return true => Cho phép tiếp tục chạy xuống hàm render
  // Nếu return false => Không cho phép chạy hàm render
  // shouldComponentUpdate(nextProps, nextState) {
  //   // Kiểm tra nếu prop message hiện tại và mới khác nhau
  //   // return true => cho phép component re-render
  //   if (this.props.message !== nextProps.message) {
  //     return true;
  //   }
  //   // Ngược lại thì không cần re-render
  //   return false;
  // }

  render() {
    console.log("WELCOME re-render");
    const { message } = this.props;
    return (
      <div>
        <h1>Welcome</h1>
        <h3>Message: {message}</h3>
      </div>
    );
  }
}

export default Welcome;
