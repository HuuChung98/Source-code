import React, { Component } from "react";
import Welcome from "./Welcome";

class Lifecycle extends Component {
  // constructor: Định nghĩa state
  constructor(props) {
    super(props);

    console.log("Constructor Run");

    this.state = {
      message: "",
      count: 0,
    };
  }

  // componentDidMount: tự động được khởi chạy 1 lần duy nhất sau khi component được khởi tạo và chạy sau hàm render
  // Dùng để:
  // - setState để component trigger re-render
  // - Tương tác với DOM: addEventListener,...
  // - Thực thi các tác vụ side effect: Call API, setTimeout, setInterval,...
  componentDidMount() {
    console.log("componentDidMount Run");

    // Delay 3s sau đó setState message
    this.timer = setTimeout(() => {
      this.setState({ message: "Hello Cybersoft" });
    }, 3000);
  }

  // componentDidUpdate: tự động được khởi chạy từ lần render thứ 2 trở đi, và chạy sau render
  // Dùng để:
  // - Dùng props hoặc state mới thay đổi để thực thi các tác vụ: Call API, setState,...
  // componentDidUpdate: cung cấp 2 tham số là giá trị trước khi thay đổi của state và props, thường dùng làm điều kiện để call API hoặc setState
  componentDidUpdate(prevProps, prevState) {
    // Lưu ý quan trọng: Khi setState trong componentDidUpdate bắt buộc phải có điều kiện
    // if(condition) {
    //   this.setState({})
    // }
    // Kiểm tra xem data cũ và hiện tại có khác nhau hay không, nếu khác mới gọi API
    // if(prevState.data !== this.state.data) {
    //   api.getData()
    // }
  }

  // componentWillUnmount: Được khởi chạy trước khi component bị huỷ bỏ
  // Dùng để: cleanup data, cancel api, cancel setTimeout,...
  componentWillUnmount() {
    clearTimeout(this.timer);
  }

  // Return về jsx để hiển thị ra giao diện
  // Tự động được gọi lại khi props hoặc state thay đổi
  render() {
    console.log("Render Run");

    return (
      <div>
        <h1>Lifecycle</h1>
        {/* <h3>{this.state.message}</h3> */}
        <p>Count: {this.state.count}</p>
        <button onClick={() => this.setState({ count: this.state.count + 1 })}>
          Increase
        </button>

        <Welcome message={this.state.message} />
      </div>
    );
  }
}

export default Lifecycle;
