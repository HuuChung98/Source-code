// import { createStore, applyMiddleware, compose } from "redux";
// // redux middleware
// import thunk from "redux-thunk";
// import rootReducer from "./redux/reducers";

// // Gộp redux devtool với middleware lại thành 1 tham số duy nhất để truyền vào store
// const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
// const enhancer = composeEnhancers(applyMiddleware(thunk));

// // createStore: dùng để tạo ra 1 redux store, tham số nhận vào là reducer
// const store = createStore(rootReducer, enhancer);

// export default store;

// =========================================================================================

// Setup với redux-toolkit
import { configureStore } from "@reduxjs/toolkit";

// import count from "./redux/reducers/count";
// import color from "./redux/reducers/color";
import cart from "./redux/reducers/cart";
// import todo from "./redux/reducers/todo";

import count from "./redux/slices/count";
import color from "./redux/slices/color";
import todo from "./redux/slices/todo";

// configureStore: mặc định đã được setup redux devtool và redux thunk
const store = configureStore({
  reducer: {
    count,
    color,
    cart,
    todo,
  },
  // devTools: false, // Setup redux devtool (mặc định là true)
  // middleware: dùng để thêm các redux middlewares (mặc định đã có sẵn thunk)
});

export default store;
