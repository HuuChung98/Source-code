import React from "react";
import Welcome from "./Welcome";
import Product from './Product'
import Comment from './Comment'

function Props() {
  return (
    <div>
      <h1>Demo Props</h1>
      <Welcome />
      <Welcome name="Cybersoft" />
      <Welcome name="BC19" />
      <Welcome name="Reactjs" />

      <br />
      <br />

      <Product name="Iphone X" description="Iphone X..." image="./img/sp_iphoneX.png" />
      <Product name="Samsung Note 7" description="Samsung Note 7..." image="./img/sp_note7.png" />
      <Product name="Vivo 850" description="Vivo 850..." image="./img/sp_vivo850.png" />

      <br />
      <br />

      <Comment
        author={{name: "Tèo", image: "https://via.placeholder.com/150"}}
        content="Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis, ipsam."
        date={new Date()}
      />

    </div>
  )
}

// class Props extends React.Component {
//   render() {
//     return (
//       <div>
//         <h1>Demo Props</h1>
//         <Welcome />
//         <Welcome name="Cybersoft" />
//         <Welcome name="BC19" />
//         <Welcome name="Reactjs" />
//       </div>
//     );
//   }
// }

export default Props
