import React, { Component } from "react";
import Avatar from "./Avatar";

class UserInfo extends Component {
  render() {
    const { user } = this.props;
    return (
      <div className="user-info">
        <Avatar user={user} />
        <div>{user.name}</div>
      </div>
    );
  }
}

export default UserInfo;
