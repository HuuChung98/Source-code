import React, { Component } from "react";

class Avatar extends Component {
  render() {
    const { user } = this.props;

    return <img className="avatar" src={user.image} alt={user.name} />;
  }
}

export default Avatar;
