import React, { Component } from "react";
import UserInfo from "./UserInfo";

class Comment extends Component {
  render() {
    const { author, content, date } = this.props;
    return (
      <div>
        {/* Author Info */}
        <UserInfo user={author} />
        {/* Comment Content */}
        <div>{content}</div>
        {/* Comment Date */}
        <div>{date.toLocaleDateString()}</div>
      </div>
    );
  }
}

export default Comment;
