import React from "react";

function Product({ name, description, image }) {
  return (
    <div className="card bg-light" style={{ width: 300 }}>
      <img
        className="card-img-top"
        src={image}
        alt="CardImage"
        style={{ maxWidth: "100%", height: 250 }}
      />
      <div className="card-body text-center">
        <h4 className="card-title text-center">{name}</h4>
        <p className="card-text">{description}</p>
        <button className="btn btn-primary">
          Detail
        </button>
        <button className="btn btn-danger">
          Cart
        </button>
      </div>
    </div>
  );
}

export default Product;
