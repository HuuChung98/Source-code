import React from "react";

// function Welcome({ name = "World" }) {
//   return <div>Hello {name}</div>;
// }

// export default Welcome;

class Welcome extends React.Component {
  render() {
    const { name } = this.props;
    return <div>Hello {name}</div>;
  }
}

Welcome.defaultProps = {
  name: "World",
};

export default Welcome;