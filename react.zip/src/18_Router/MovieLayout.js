import React from "react";
import { Outlet } from "react-router-dom";

export default function MovieLayout() {
  console.log('MovieLayout Render')
  return (
    <div>
      {/* <Header /> */}
      <div className="bg-primary text-white p-5 text-center">Movie Header</div>

      {/* Route của MovieList hoặc MovieDetails sẽ được render ra tại đây */}
      <Outlet />

      {/* <Footer /> */}
      <div className="bg-secondary text-white p-5 text-center">
        Movie Footer
      </div>
    </div>
  );
}
