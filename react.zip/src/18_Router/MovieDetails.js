import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

export default function MovieDetails() {
  // Để lấy ra params trên url ta dùng hook useParams
  // path: /movies/:movieId => useParams trả về 1 object có key movieId bên trong
  const { movieId } = useParams();
  // Dùng useNavigate để điều hướng url
  const navigate = useNavigate();

  const [movie, setMovie] = useState(null);

  const fetchMovie = async () => {
    try {
      const { data } = await axios.get(
        `https://625a732843fda1299a17d4e6.mockapi.io/api/movies/${movieId}`
      );
      setMovie(data);
    } catch (error) {
      console.log(error);
      // Nhảy xuông catch nghĩa là id không hợp lệ để lấy chi tiết phim
      // Chuyển url về trang not-found
      navigate("/not-found", { replace: true });
    }
  };

  useEffect(() => {
    // Dùng movieId để call API lấy chi tiết phim
    fetchMovie();
  }, [movieId]);

  if (!movie) {
    return null;
  }

  return (
    <div className="container">
      <div className="row">
        <div className="col-sm-6">
          <img src={movie.img} alt={movie.title} width="100%" height="500px" />
        </div>
        <div className="col-sm-6">
          <h1>{movie.title}</h1>
          <p>{movie.desc}</p>
        </div>
      </div>
    </div>
  );
}
