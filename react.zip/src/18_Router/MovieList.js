import React, { useState, useEffect, useRef } from "react";
import { Link, useSearchParams } from "react-router-dom";
import axios from "axios";

export default function MovieList() {
  const [movies, setMovies] = useState([]);
  const inpSearch = useRef(null);

  // useSearchParams trả về 1 array gồm 2 giá trị
  // searchParams: là 1 object chứa tất cả giá trị của search params trên url
  // setSearchParams: là 1 hàm để thay đổi giá trị search params trên url
  const [searchParams, setSearchParams] = useSearchParams();

  const fetchMovies = async () => {
    try {
      const { data } = await axios.get(
        "https://625a732843fda1299a17d4e6.mockapi.io/api/movies",
        {
          params: {
            title: searchParams.get("search"),
            page: searchParams.get("page") || 1,
            limit: 6,
          },
        }
      );
      setMovies(data);
    } catch (error) {
      console.log(error);
    }
  };

  const onSearch = () => {
    const value = inpSearch.current.value; // input value
    // Lưu trữ value trên url bằng search params: ?
    searchParams.set("search", value);
    setSearchParams(searchParams);
  };

  const changePage = (page) => {
    // Lưu trữ page trên url bằng search params: ?
    searchParams.set("page", page);
    setSearchParams(searchParams);
  };

  useEffect(() => {
    fetchMovies();
  }, [searchParams]);

  return (
    <div className="container">
      {/* Search */}
      <div className="form-inline">
        <input
          type="text"
          className="form-control"
          ref={inpSearch}
          defaultValue={searchParams.get("search")}
        />
        <button className="btn btn-primary" onClick={onSearch}>
          Search
        </button>
      </div>

      <div className="row">
        {movies.map((movie) => {
          return (
            <div key={movie.id} className="col-sm-4">
              <div className="card">
                <img
                  src={movie.img}
                  alt={movie.title}
                  className="card-img"
                  width="100%"
                  height="300px"
                />
                <div className="card-body">
                  <h3 className="card-title">{movie.title}</h3>
                  <p className="card-text">{movie.desc}</p>
                  <Link className="btn btn-success" to={`/movies/${movie.id}`}>
                    Details
                  </Link>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <button className="btn btn-secondary" onClick={() => changePage(1)}>
        1
      </button>
      <button className="btn btn-secondary" onClick={() => changePage(2)}>
        2
      </button>
    </div>
  );
}
