import React, { Component } from "react";

class ExChangeCar extends Component {
  constructor() {
    super();
    this.state = {
      imgCar: "./img/black-car.jpg",
    };
  }

  changeColor = (color) => {
    // Thay đổi state imgCar
    // this.state.imgCar = `./img/${color}-car.jpg`;
    // this.state = {
    //   imgCar: `./img/${color}-car.jpg`;
    // }
    this.setState({
      imgCar: `./img/${color}-car.jpg`,
    });
  };

  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-sm-6">
            <h3>Please choose your favorite car's color</h3>
            <img src={this.state.imgCar} alt="car" width="100%" />
          </div>
          <div className="col-sm-6 d-flex justify-content-between align-items-baseline">
            <button
              className="btn btn-danger"
              onClick={() => this.changeColor("red")}
            >
              Red Color
            </button>
            <button
              className="btn btn-secondary"
              onClick={() => this.changeColor("silver")}
            >
              Silver Color
            </button>
            <button
              className="btn btn-dark"
              onClick={() => this.changeColor("black")}
            >
              Black Color
            </button>
          </div>
        </div>
      </div>
    );
  }
}

export default ExChangeCar;
