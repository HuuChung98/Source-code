import React, { Component } from "react";

class ConditionalRendering extends Component {
  constructor() {
    super();

    this.state = {
      isLoggedIn: false, // default là chưa đăng nhập
      messages: ["BC19", "Cybersoft", "Reactjs"],
    };
  }

  handleLogin = () => {
    this.setState({
      isLoggedIn: true,
    });
  };

  handleLogout = () => {
    this.setState({
      isLoggedIn: false,
    });
  };

  markAllReadMessage = () => {
    this.setState({
      messages: [],
    });
  };

  render() {
    const { isLoggedIn, messages } = this.state;

    // Chưa đăng nhập
    if (!isLoggedIn) {
      return (
        <div>
          <h1>Please login</h1>
          <button onClick={this.handleLogin}>Login</button>
        </div>
      );
    }

    // Đã đăng nhập
    return (
      <div>
        <h1>Welcome back!!!</h1>
        {messages.length > 0 && (
          <div>
            <p>
              You have {messages.length} unread messages.
              <button onClick={this.markAllReadMessage}>Mark all read</button>
            </p>
          </div>
        )}
        <button onClick={this.handleLogout}>Logout</button>
      </div>
    );
  }
}

export default ConditionalRendering;
