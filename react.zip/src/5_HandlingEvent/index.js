import React, { Component } from "react";

export class HandlingEvent extends Component {
  constructor() {
    super();

    this.state = {
      isActive: false,
      username: "Hello Cybersoft", // Nhằm mục đích lưu trữ giá trị của input username, để có thế sử dụng ở mọi nơi trong component
    };
  }

  showAlert = () => {
    alert("Clicked");
  };

  showMessage = (name) => {
    alert(`Hello ${name}`);
  };

  toggleActive = () => {
    this.setState({
      isActive: !this.state.isActive,
    });
  };

  handleChange = (evt) => {
    console.log(evt.target.value);
    this.setState({
      username: evt.target.value,
    });
  };

  handleSubmit = (evt) => {
    // evt.preventDefault(): ngăn cản hành vi submit mặc định của form
    evt.preventDefault()
    console.log(this.state.username)
    alert('Submitted')
  }

  render() {
    return (
      <div>
        <h1>Demo Handling Event</h1>
        <button className="btn btn-primary" onClick={this.showAlert}>
          Show Alert
        </button>
        <button
          className="btn btn-secondary"
          onClick={() => this.showMessage("Dan Nguyen")}
        >
          Show Message
        </button>
        <button
          className={`btn btn-${this.state.isActive ? "success" : "danger"}`}
          onClick={this.toggleActive}
        >
          Toggle Active
        </button>

        <br />
        <br />

        <form onSubmit={this.handleSubmit}>
          <div className="form-group">
            <label htmlFor="username">Username</label>
            <input
              type="text"
              id="username"
              value={this.state.username}
              className="form-control"
              onChange={this.handleChange}
            />
          </div>
          <button type="submit">Submit</button>
        </form>
      </div>
    );
  }
}

export default HandlingEvent;
