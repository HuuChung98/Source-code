import React, { Component } from "react";
import axios from "axios";

import UserForm from "./UserForm";
import UserList from "./UserList";
import SearchUser from "./SearchUser";
// import data from "./data.json";

class UserManagement extends Component {
  constructor(props) {
    super(props);

    this.state = {
      users: [],
      selectedUser: {},
      search: "",
    };
  }

  handleDeleteUser = async (userId) => {
    // Xử lý xoá user
    // const users = this.state.users.filter((user) => user.id !== userId);
    // this.setState({ users });

    // Gọi API xoá user
    await axios.delete(
      `https://625a732843fda1299a17d4e6.mockapi.io/api/users/${userId}`
    );
    // Gọi tới hàm handleGetUsers để gọi API lấy data mới nhất từ server
    this.handleGetUsers();
  };

  handleSelectUser = async (userId) => {
    // Tránh gọi lại API nếu user đang chọn trùng với user đã chọn trước đó
    if (userId === this.state.selectedUser.id) {
      return;
    }

    try {
      // Gọi API
      const { data } = await axios.get(
        `https://625a732843fda1299a17d4e6.mockapi.io/api/users/${userId}`
      );
      // Thành công => setState selectedUser
      this.setState({ selectedUser: data });
    } catch (error) {
      console.log(error);
    }
  };

  handleGetUsers = async () => {
    try {
      // Gọi API
      const { data } = await axios.get(
        "https://625a732843fda1299a17d4e6.mockapi.io/api/users",
        {
          params: {
            name: this.state.search,
          },
        }
      );
      // Thành công => setState users bằng data từ API
      this.setState({ users: data });
    } catch (error) {
      // Thất bại
      console.log(error);
    }
  };

  handleSearchUser = (searchString) => {
    // PA1:
    // this.handleGetUsers(searchString);
    // PA2:
    this.setState({ search: searchString });
  };

  componentDidMount() {
    // Gọi tới hàm handleGetUsers
    this.handleGetUsers();
  }

  componentDidUpdate(_, prevState) {
    // Kiểm tra nếu state search thay đổi => Gọi API get users
    if (prevState.search !== this.state.search) {
      this.handleGetUsers();
    }
  }

  render() {
    const { users, selectedUser } = this.state;

    return (
      <div className="container">
        <h1 className="text-center">User Management</h1>

        <UserForm
          // key={selectedUser.id}
          user={selectedUser}
          onSubmitSuccess={this.handleGetUsers}
        />

        <SearchUser onSearch={this.handleSearchUser} />

        <UserList
          users={users}
          onSelect={this.handleSelectUser}
          onDelete={this.handleDeleteUser}
        />
      </div>
    );
  }
}

export default UserManagement;
