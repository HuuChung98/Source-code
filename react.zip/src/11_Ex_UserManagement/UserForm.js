import React, { Component } from "react";
import axios from "axios";

class UserForm extends Component {
  constructor(props) {
    super(props);

    this.state = {
      // values: quản lý tất cả giá trị input của form
      values: {
        id: props.user.id || "",
        name: props.user.name || "",
        gender: props.user.gender || "",
        dateOfBirth: props.user.dateOfBirth || "",
        email: props.user.email || "",
        address: props.user.address || "",
      },

      // error: quản lý lỗi từ server trả về
      error: null,
    };
  }

  handleChange = (evt) => {
    const { name, value } = evt.target;
    // Khi state là 1 object, mà ta chỉ muốn thay đổi 1 giá trị bên trong object đó, ta cần nhớ sao chép lại những giá trị khác và sau đó thay đổi giá trị muốn thay đổi
    // Khi update state mà quá trình tính toán có sử dụng lại giá trị hiện tại của state, ta nên viết hàm setState theo dạng callback
    this.setState((state) => ({
      values: {
        ...state.values,
        [name]: value,
      },
    }));
  };

  handleSubmit = async (evt) => {
    evt.preventDefault();
    // Gửi thông tin của form lên component cha để thêm/cập nhật users
    // this.props.onSubmit(this.state.values);

    const { id, ...payload } = this.state.values;

    try {
      if (id) {
        // Cập nhật
        await axios.put(
          `https://625a732843fda1299a17d4e6.mockapi.io/api/users/${id}`,
          payload
        );
      } else {
        // Thêm mới
        await axios.post(
          "https://625a732843fda1299a17d4e6.mockapi.io/api/users",
          payload
        );
      }
      // Thành công gọi prop onSubmitSuccess, để báo cho component cha biết và gọi API get users
      this.props.onSubmitSuccess();
      // Reset form
      this.setState({
        values: {
          name: "",
          gender: "",
          email: "",
          address: "",
          dateOfBirth: "",
        },
      });
    } catch (error) {
      // Có lỗi từ server trả về => setState cho biến error
      this.setState({ error: error.response.data });
    }
  };

  componentDidUpdate(prevProps) {
    // Khi prop user thay đổi, component sẽ re-render và gọi tới vào hàm này
    if (prevProps.user.id !== this.props.user.id) {
      // setState giá trị hiện tại của prop user cho state values
      this.setState({ values: this.props.user });
    }
  }

  render() {
    const { values } = this.state;
    return (
      <form className="row" onSubmit={this.handleSubmit}>
        <div className="col-sm-6">
          <div className="form-group">
            <label htmlFor="name">Name</label>
            <input
              type="text"
              id="name"
              name="name"
              value={values.name}
              className="form-control"
              onChange={this.handleChange}
            />
          </div>
          <div className="form-group">
            <label htmlFor="gender">Gender</label>
            <select
              id="gender"
              name="gender"
              value={values.gender}
              className="form-control"
              onChange={this.handleChange}
            >
              <option value="">Select gender</option>
              <option value="Men">Men</option>
              <option value="Women">Women</option>
              <option value="Other">Other</option>
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="dateOfBirth">Date of Birth</label>
            <input
              type="text"
              id="dateOfBirth"
              name="dateOfBirth"
              value={values.dateOfBirth}
              className="form-control"
              onChange={this.handleChange}
            />
          </div>
        </div>
        <div className="col-sm-6">
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              value={values.email}
              className="form-control"
              onChange={this.handleChange}
            />
          </div>
          <div className="form-group">
            <label htmlFor="address">Address</label>
            <input
              type="text"
              id="address"
              name="address"
              value={values.address}
              className="form-control"
              onChange={this.handleChange}
            />
          </div>
        </div>

        <button className="btn btn-success">Submit</button>
      </form>
    );
  }
}

export default UserForm;
