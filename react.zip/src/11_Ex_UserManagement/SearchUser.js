import React, { Component } from "react";

class SearchUser extends Component {
  constructor(props) {
    super(props);

    this.state = {
      searchString: "",
    };
  }

  render() {
    const { onSearch } = this.props;
    const { searchString } = this.state;
    return (
      <div className="form-inline mt-4">
        <input
          type="text"
          className="form-control mr-2"
          placeholder="Search name..."
          value={searchString}
          onChange={(evt) => this.setState({ searchString: evt.target.value })}
        />
        <button
          className="btn btn-success"
          onClick={() => onSearch(searchString)}
        >
          Search
        </button>
      </div>
    );
  }
}

export default SearchUser;
