import { createSlice } from "@reduxjs/toolkit";

// Thông thường khi làm việc với redux ta thường tạo ra 3 file: constants, action, reducer

// createSlice: sẽ giúp đơn giản hoá cách làm việc với redux, thay vì phải tách ra 3 file constants, action, reducer ta chỉ cần duy nhất hàm createSlice

const countSlice = createSlice({
  name: "count", // key định danh cho slice (phải là duy nhất)
  initialState: 0, // default state
  reducers: {
    increase(state) {
      return state + 1;
    },
    decrease(state) {
      return state - 1;
    },
  },
});

// export actions
export const { increase, decrease } = countSlice.actions;
// export reducer
export default countSlice.reducer;




