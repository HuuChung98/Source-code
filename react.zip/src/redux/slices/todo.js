import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

export const getTodos = createAsyncThunk(
  "todo/getTodos",
  // Hàm call API: nhận vào 2 tham số:
  // - Tham số 1: params truyền vào khi gọi hàm
  // - Tham số 2: là thunkAPI là 1 object gồm dispatch, getState
  // Chỉ cần gọi API và return về data, việc dispatch các action pending, fullfiled, rejected sẽ được createAsyncThunk quản lý giúp mình
  async (_, { getState }) => {
    try {
      const { search, filter } = getState().todo;
      const { data } = await axios.get(
        "https://625a732843fda1299a17d4e6.mockapi.io/api/todos",
        {
          params: {
            title: search,
          },
        }
      );
      return data;
    } catch (error) {
      console.log(error);
    }
  }
);

const initialState = {
  todos: [],
  search: "",
  filter: "all",
  isLoading: false, // hiển thị loading khi call API
  error: null, // nhận lỗi từ API
};

const todoSlice = createSlice({
  name: "todo",
  initialState,
  reducers: {
    // getTodoPending(state) {
    //   return { ...state, isLoading: true };
    // },
    // getTodoFullfiled(state, action) {
    //   return { ...state, isLoading: false, todos: action.payload };
    // },
    // getTodoRejected(state, action) {
    //   return { ...state, isLoading: false, error: action.payload };
    // },
  },
  // Dùng để xử lý thunk actions
  extraReducers: {
    [getTodos.pending]: (state) => {
      return { ...state, isLoading: true };
    },
    [getTodos.fulfilled]: (state, action) => {
      return { ...state, isLoading: false, todos: action.payload };
    },
    [getTodos.rejected]: (state, action) => {
      return { ...state, isLoading: false, error: action.payload };
    },
  },
});

export default todoSlice.reducer;








// const { getTodoPending, getTodoFullfiled, getTodoRejected } = todoSlice.actions;
// export const getTodos = () => {
//   return async (dispatch, getState) => {
//     try {
//       const { search, filter } = getState().todo;
//       dispatch(getTodoPending());
//       const { data } = await axios.get(
//         "https://625a732843fda1299a17d4e6.mockapi.io/api/todos",
//         {
//           params: {
//             title: search,
//           },
//         }
//       );
//       dispatch(getTodoFullfiled(data));
//     } catch (error) {
//       dispatch(getTodoRejected(error.response.data));
//     }
//   };
// };
