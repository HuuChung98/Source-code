// Tạo init state
const initialState = {
  products: [
    {
      id: 1,
      name: "Iphone 13",
      display: "Super Retina XDR OLED, 120Hz, 6.7 inches, 1284 x 2778 pixels",
      os: "iOS 15",
      camera:
        "12 MP, f/1.5, 26mm (wide), 1.9µm, dual pixel PDAF, sensor-shift OIS",
      memory: "6GB 256GB",
      price: 31000000,
      image:
        "https://cdn.tgdd.vn/Products/Images/42/223602/iphone-13-midnight-2-600x600.jpg",
    },
    {
      id: 2,
      name: "Samsung galaxy S22 Ultra",
      display: "Dynamic AMOLED 2X, 120Hz, 6.1 inches, 1080 x 2340 pixels",
      os: "Android 12, One UI 4.1",
      camera: "50 MP, f/1.8, 23mm (wide), 1/1.56, 1.0µm, Dual Pixel PDAF, OIS",
      memory: "12GB 256GB",
      rom: "128 GB",
      price: 32000000,
      image:
        "https://cdn.tgdd.vn/Files/2021/12/06/1402535/galaxys22ultra_3_1280x720-800-resize.jpg",
    },
    {
      id: 3,
      name: "Oppo Find X5 Pro",
      display: "LTPO2 AMOLED, 120 Hz, 6.7 inches, 1440 x 3216 pixels",
      os: "Android 12, ColorOS 12.1",
      camera:
        "50 MP, f/1.7, 25mm (wide), 1/1.56, 1.0µm, multi-directional PDAF, OIS (3-axis sensor-shift, 2-axis lens-shift)",
      memory: "12GB 256GB",
      price: 34000000,
      image:
        "https://cdn.pocket-lint.com/r/s/1200x/assets/images/159952-phones-news-oppo-find-x5-pro-renders-image1-p8ufbrezxs.jpg",
    },
  ],
  carts: [],
};

const cartReducer = (state = initialState, action) => {
  switch (action.type) {
    case "ADD_TO_CART": {
      const product = action.data;
      // Kiểm tra xem sản phẩm đã tồn tại trong giỏ hàng hay chưa
      const index = state.carts.findIndex((item) => item.id === product.id);

      // Chưa tồn tại trong giỏ hàng
      if (index === -1) {
        const carts = [...state.carts, { ...product, quantity: 1 }];
        return { ...state, carts };
      }

      // Đã tồn tại trong giỏ hàng
      const carts = state.carts.map((item) => {
        return item.id === product.id
          ? { ...item, quantity: item.quantity + 1 }
          : item;
      });

      return { ...state, carts };
    }
    case "INCREASE_QUANTITY": {
      const productId = action.data; // data là id của product muốn tăng số lượng
      const newCarts = state.carts.map((item) => {
        // Duyệt qua từng sản phẩm trong giỏ hàng, kiểm tra xem sản phẩm đó có id trùng với id của sản phẩm muốn tăng số lượng hay không
        if (item.id === productId) {
          return { ...item, quantity: item.quantity + 1 };
        }
        // Nếu không phải chỉ return về chính sản phẩm đó
        return item;
      });

      // state.carts = newCarts;
      // return state; // return về object state hiện tại

      // Redux sẽ kiểm tra state có thay đổi hay không bằng cách so sánh shallow compare (===) => Dù có thay đổi state mà không return về 1 object mới thì redux vẫn xem như không có sự thay đổi nào và sẽ không trả ra state mới cho component
      return { ...state, carts: newCarts }; // return về 1 object state mới
    }
    case "DECREASE_QUANTITY": {
      const productId = action.data; // data là id của product muốn giảm số lượng

      // Tìm sản phẩm có id trùng với productId muốn xoá để kiểm tra số lượng
      const { quantity } = state.carts.find((item) => item.id === productId);

      // Nếu số lượng đang là 1 => xoá sản phẩm
      if (quantity === 1) {
        const newCarts = state.carts.filter((item) => item.id !== productId);
        return { ...state, carts: newCarts };
      }

      // Số lượng lớn hơn 1 => giảm số lượng
      const newCarts = state.carts.map((item) => {
        if (item.id === productId) {
          return { ...item, quantity: item.quantity - 1 };
        }
        return item;
      });
      return { ...state, carts: newCarts };
    }
    case "REMOVE_PRODUCT": {
      const productId = action.data; // data là id của product muốn xoá
      const carts = state.carts.filter((item) => item.id !== productId);
      return { ...state, carts };

      // return {
      //   ...state,
      //   carts: state.carts.filter((item) => item.id !== productId),
      // };
    }
    default:
      return state;
  }
};

export default cartReducer;
