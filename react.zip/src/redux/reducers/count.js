// Reducer là 1 function nhận vào state và action, sau đó xử lý và return về state
const countReducer = (state = 0, action) => {
  switch (action.type) {
    case "INCREASE":
      return state + 1;
    case "DECREASE":
      return state - 1;
    default:
      return state;
  }
};

export default countReducer;
