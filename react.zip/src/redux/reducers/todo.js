import * as actionTypes from "../constants/todo";

// State default
const inititalState = {
  todos: [],
  search: "",
  filter: "all",
  isLoading: false, // hiển thị loading khi call API
  error: null, // nhận lỗi từ API
};

// Reducer
const todoReducer = (state = inititalState, action) => {
  switch (action.type) {
    // PENDING: set loading thành true
    case actionTypes.GET_TODOS_PENDING: {
      return { ...state, isLoading: true };
    }
    // FULLFILED: set loading thành false và set data từ API
    case actionTypes.GET_TODOS_FULLFILED: {
      return {
        ...state,
        isLoading: false,
        todos: action.data, // data từ API
      };
    }
    // REJECTED: set loading thành false và set error từ API
    case actionTypes.GET_TODOS_REJECTED: {
      return {
        ...state,
        isLoading: false,
        error: action.error, // error từ API
      };
    }
    case actionTypes.CHANGE_SEARCH: {
      return { ...state, search: action.data };
    }
    default:
      return state;
  }
};

export default todoReducer;
