import { combineReducers } from "redux";
import countReducer from "./count";
import colorReducer from "./color";
import cartReducer from "./cart";
import todoReducer from "./todo";

// Root reducer là nơi khai báo tất cả các reducer con
const rootReducer = combineReducers({
  count: countReducer, // child reducer
  color: colorReducer, // child reducer
  cart: cartReducer,
  todo: todoReducer,
});

export default rootReducer;
