import axios from "axios";
import * as actionTypes from "../constants/todo";

// redux chỉ cho phép action là 1 plain

// Cần phải sử dụng 1 redux middleware là redux thunk để có thể call API trong action sau đó dispatch 1 action mới để gửi data tới store
export const getTodos = () => {
  // redux-thunk là một redux middleware cho phép viết các action trả về 1 function thay vì là một object bằng cách trì hoãn việc đưa action vào reducer
  return async (dispatch, getState) => {
    try {
      // getState là hàm lấy state từ store
      const { search, filter } = getState().todo;
      // Trước khi call API dispatch action pending
      dispatch({ type: actionTypes.GET_TODOS_PENDING });
      // Call API
      const { data } = await axios.get(
        "https://625a732843fda1299a17d4e6.mockapi.io/api/todos",
        {
          params: {
            title: search,
          },
        }
      );
      // Thành công dispatch action fullfiled
      dispatch({ type: actionTypes.GET_TODOS_FULLFILED, data });
    } catch (error) {
      // Thất bại dispatch action rejected
      dispatch({
        type: actionTypes.GET_TODOS_REJECTED,
        error: error.response.data, // format error của axios
      });
    }
  };
};

export const deleteTodo = (todoId) => {
  // return về 1 function middleware
  return async (dispatch) => {
    try {
      // Call API
      await axios.delete(
        `https://625a732843fda1299a17d4e6.mockapi.io/api/todos/${todoId}`
      );
      // Thành công => Gọi tiếp tới action getTodos
      dispatch(getTodos());
    } catch (error) {
      console.log(error);
    }
  };
};

export const completeTodo = (todo) => {
  return async (dispatch) => {
    try {
      const { id, ...payload } = todo;
      // Call API
      await axios.put(
        `https://625a732843fda1299a17d4e6.mockapi.io/api/todos/${id}`,
        { ...payload, isCompleted: true }
      );
      // Thành công => Gọi tiếp tới action getTodos
      dispatch(getTodos());
    } catch (error) {
      console.log(error);
    }
  };
};

export const changeSearch = (value) => {
  return {
    type: actionTypes.CHANGE_SEARCH,
    data: value,
  };
};
