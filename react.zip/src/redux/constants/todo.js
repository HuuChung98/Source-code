// todo constants
// Định nghĩa các action types cho action và reducer

// Khi 1 action dược dispatch nó sẽ đi vào tất cả các reducer
// Thêm prefix vào các action types để tránh trùng lặp nhau giữa các reducer
const PREFIX = "todo";

// Với 1 async action ta sẽ tạo ra 3 action types
// Khi request đang được thực thi
export const GET_TODOS_PENDING = `${PREFIX}/GET_TODOS_PENDING`;
// Khi request thành công
export const GET_TODOS_FULLFILED = `${PREFIX}/GET_TODOS_FULLFILED`;
// Khi request thất bại
export const GET_TODOS_REJECTED = `${PREFIX}/GET_TODOS_REJECTED`;

export const CHANGE_SEARCH = `${PREFIX}/CHANGE_SEARCH`; // todo/CHANGE_SEARCH
