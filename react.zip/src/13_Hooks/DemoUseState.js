// Để sử dụng state trong function component ta import useState
import React, { useState } from "react";

const DemoUseState = () => {
  // useState return về 1 array gồm 2 phần tử
  // Phần tử thứ 1 là biến chứa giá trị hiện tại của state
  // Phần tử thứ 2 là một function dùng để thay đổi state
  const [count, setCount] = useState(0);
  // Để tạo nhiều state ta chỉ cần gọi useState nhiều lần
  const [message, setMessage] = useState("");
  // State là array
  const [users, setUsers] = useState(["Khải", "Hiếu", "Quân"]);
  // State là object
  const [values, setValues] = useState({ username: "", email: "" });

  // Hàm này luôn luôn chạy lại mỗi lần component re-render tuy nhiên nó chỉ được sử dụng 1 lần duy nhất làm default value cho state
  // const expensiveCalc = () => {
  //   // logic...
  //   return Math.random() * 100;
  // };
  // Đầu vào của state là 1 function tính toán phức để return về 1 value
  // const [complexValue, setComplexValue] = useState(expensiveCalc());

  // useState cho phép nhận vào default value là một function và return về 1 value
  // Ưu diểm của việc này chính là function này chỉ được gọi một lần duy nhất để khởi tạo giá trị default cho state
  const [complexValue, setComplexValue] = useState(() => {
    // logic...
    return Math.random() * 100;
  });

  const handleAddUser = () => {
    const name = prompt("Vui lòng nhập tên muốn thêm:");
    // Lưu ý khi thay đổi state là array thì ta cần truyền vào 1 array mới
    // Để những giá trị hiện tại trong array không bị mất khi thay đổi, ta cần sao chép các giá trị hiện tại trước khi thay đổi
    // Hàm setState có thể nhận vào tham số là 1 function, trong function sẽ trả ra 1 param là giá trị hiện tại của state
    setUsers((state) => [...state, name]);
  };

  const handleDeleteUser = () => {
    const name = prompt("Vui lòng nhập tên muốn xoá:");

    // const newUsers = users.filter((user) => user !== name);
    // setUsers(newUsers);

    setUsers((state) => state.filter((user) => user !== name));
  };

  const handleChange = (evt) => {
    const { name, value } = evt.target;
    // Tương tự như array khi thay đổi state là object ta cũng cần phải truyền vào 1 object mới
    setValues((state) => ({ ...state, [name]: value }));
  };

  return (
    <div>
      <h1>UseState</h1>
      <p>Count: {count}</p>
      <button onClick={() => setCount(count + 1)}>Increase</button>

      <br />
      <br />

      <p>Message: {message}</p>
      <button onClick={() => setMessage("Hello Cybersoft")}>
        Change Message
      </button>

      <br />
      <br />

      <h3>Demo array</h3>
      {users.map((user, index) => (
        <p key={index}>{user}</p>
      ))}
      <button onClick={handleAddUser}>Add User</button>
      <button onClick={handleDeleteUser}>Delete User</button>

      <br />
      <br />
      <h3>Demo object</h3>
      <div>
        <label>Username:</label>
        <input
          type="text"
          name="username"
          value={values.username}
          onChange={handleChange}
        />
      </div>
      <div>
        <label>Email:</label>
        <input
          type="text"
          name="email"
          value={values.email}
          onChange={handleChange}
        />
      </div>
    </div>
  );
};

export default DemoUseState;
