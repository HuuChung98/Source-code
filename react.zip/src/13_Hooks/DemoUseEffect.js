import React, { useState, useEffect } from "react";

/**
 * MOUNTING:
 * -  rendering
 * -  run useEffect()
 *
 * UPDATING: (props hoặc state thay đổi)
 * -  rendering
 * -  run useEffect() cleanup - Nếu depedencies thay đổi
 * -  run useEffect() - Nếu depedencies thay đổi
 *
 * UNMOUNTING:
 * -  run useEffect() cleanup
 */

const DemoUseEffect = () => {
  const [count, setCount] = useState(0);
  const [color, setColor] = useState("");

  // Tự động được thực thi sau mỗi lần render (rất ít khi đươc sử dụng)
  useEffect(() => {
    // Thực thi những logic side effect: call API, setTimeout, DOM,...
    console.log("effect 1");

    // cleanup effect
    // Được chạy trước lần run effect tiếp theo hoặc khi component bị unmount
    return () => {
      // Trước khi bắt đầu run effect mới ta cần cleanup: cancel API, clearTimeout,...
      console.log("cleanup effect 1");
    };
  });

  // Với tham số thứ 2 là 1 array rỗng useEffect này sẽ tự động được thực thi 1 lần duy nhất sau lần render đầu tiên
  useEffect(() => {
    console.log("effect 2, []");

    // cleanup effect
    // Được chạy khi component bị unmount
    return () => {
      console.log("cleanup effect 2");
    };
  }, []);

  // Với tham số thứ 2 là 1 array có chứa các biến state hoặc props (depedencies), useEffect này sẽ tự động được thực thi ở lần render đầu tiên, những lần render sau chỉ được thực thi khi depedencies thay đổi
  useEffect(() => {
    console.log("effect 3, [count]");

    // cleanup effect
    // Được chạy trước lần run effect tiếp theo (depedencies bị thay đổi) hoặc khi component bị unmount
    return () => {
      console.log("cleanup effect 2");
    };
  }, [count]);

  useEffect(() => {
    console.log("effect 4, [color]");
  }, [color]);

  const handleSetColor = () => {
    const color = prompt("Input color:");
    setColor(color);
  };

  console.log("Component render");
  return (
    <div>
      <h1>UseEffect</h1>
      <p>Count: {count}</p>
      <button onClick={() => setCount(count + 1)}>Increase</button>

      <br />
      <br />

      <p>Color: {color}</p>
      <button onClick={handleSetColor}>Set color</button>
    </div>
  );
};

export default DemoUseEffect;
