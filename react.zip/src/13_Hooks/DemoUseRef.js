import React, { useState, useRef, useEffect } from "react";

const DemoUseRef = () => {
  // Dùng ref để truy cập vào DOM của element
  const h1Ref = useRef();

  // State
  const [username, setUsername] = useState("");
  // Ref
  const emailRef = useRef();

  // Ngoài ra ref còn dùng để lưu trữ data giống state, tuy nhiên khi ref thay đổi component không bị re-render
  const [count, setCount] = useState(0);
  const countRef = useRef(0);
  const prevCount = useRef(); // Lưu trữ giá trị trước đó của state count

  const handleSubmit = () => {
    // Value của input control bằng state
    console.log("State:", username);
    // Value của input control bằng ref
    console.log("Ref:", emailRef.current.value);
  };

  // Lưu trữ giá trị trước đó của state count cho ref
  useEffect(() => {
    prevCount.current = count;
  }, [count]);

  console.log("Render");
  return (
    <div>
      <h1 ref={h1Ref}>Demo Ref</h1>
      {/* State - Controlled component */}
      <div className="form-group">
        <label>State</label>
        <input
          type="text"
          className="form-control"
          value={username}
          onChange={(evt) => setUsername(evt.target.value)}
        />
      </div>

      {/* Ref - Uncontrolled component */}
      <div className="form-group">
        <label>Ref</label>
        <input type="text" className="form-control" ref={emailRef} />
      </div>

      <button className="btn btn-success" onClick={handleSubmit}>
        Submit
      </button>

      <br />
      <br />

      <p>Count: {count}</p>
      <p>PrevCount: {prevCount.current}</p>
      <p>CountRef: {countRef.current}</p>
      <button onClick={() => setCount(count + 1)}>Increase Count</button>
      <button onClick={() => countRef.current++}>Increase CountRef</button>
    </div>
  );
};

export default DemoUseRef;
