import React from "react";

// children là prop của component chứa nội dung bên trong 2 tag đóng mở của component
function Button({ variant, className, children, ...props }) {
  let classes = `btn btn-${variant} ${className}`;

  return (
    <button {...props} className={classes}>
      {children}
    </button>
  );
}

Button.defaultProps = {
  type: "button",
  disabled: false,
  className: "",
};

export default Button;
