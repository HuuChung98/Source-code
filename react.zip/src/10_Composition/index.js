import React from "react";
import Button from "./Button";
import Card from "./Card";

function Composition() {
  return (
    <div>
      <h1>Composition</h1>

      <Button type="button" variant="primary">
        {/* Nội dung nằm bên trong 2 tag đóng mở của component sẽ được đưa vào prop children của component */}
        Primary
      </Button>

      <Button variant="secondary" className="w-50">
        Secondary
      </Button>

      <Button variant="warning">Warning</Button>

      <Button variant="danger">Danger</Button>

      <br />
      <br />

      <Card
        heading="Student"
        headerClassName="bg-warning"
        footer={<button className="btn btn-primary">Details</button>}
      >
        <h3>Name: Nguyễn Văn Tèo</h3>
        <p>Class: Bootcamp 19</p>
      </Card>

      <Card
        heading="Product"
        headerClassName="bg-primary"
        footer={<button className="btn btn-success">Buy</button>}
      >
        <img src="./img/sp_iphoneX.png" alt="iphone" width="300px" />
        <h3>Iphone X</h3>
      </Card>
    </div>
  );
}

export default Composition;
