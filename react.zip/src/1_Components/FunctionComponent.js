// Để tạo nhanh function component dùng snippet: rfce
import React from 'react'

function FunctionComponent() {
  const title = "BC19 - Function Component";

  // return về jsx
  return (
    <div>
      <h1>{title}</h1>
    </div>
  );
}

export default FunctionComponent;

