// Để tạo nhanh class component dùng snippet: rce
import React, { Component } from 'react'

class ClassComponent extends Component {
  render() {
    const title = 'BC19 - Class Component'
    // return về jsx
    return (
      <div>
        <h1>{title}</h1>
      </div>
    )
  }
}

export default ClassComponent