// Tại thời điểm này khi học state ta sẽ tạo class component
import React, { Component } from "react";

class State extends Component {
  constructor() {
    super();
    // Ta dùng state để quản lý trạng thái của component
    // khi state thay đổi component sẽ tự động gọi lại hàm render() và hiển thị những thay đổi mới nhất lên UI
    this.state = {
      count: 0,
    };
  }

  // Tạo property của class
  message = ""

  increase = () => {
    // Thay đổi giá trị của state count

    // Không được thay đổi trực tiếp giá trị của state
    // this.state.count += 1

    // Khi muốn thay đổi giá trị của state ta phải dùng hàm setState
    this.setState(
      {
        count: this.state.count + 1,
      },
      () => {
        // Để lấy được kết quả sau khi setState ta sẽ lấy trong callback ở tham số thứ 2 của hàm setState
        console.log("Gọi trong callback của setState:", this.state.count);
      }
    );
    // Bởi vì hàm setState là 1 hàm bất đồng bộ, nên ta không thể lấy kết quả mới sau khi gọi setState ở đây
    console.log("Gọi sau khi setState:", this.state.count);
  };

  changeMessage = () => {
    // Khi thay đổi các thuộc tính của class không phải là state, component sẽ không render lại
    this.message = "Hello BC19"
  }

  render() {
    return (
      <div>
        <h1>Demo State</h1>

        <div>
          <p>Count: {this.state.count}</p>
          <button onClick={this.increase}>Increase</button>
        </div>

        <div>
          <p>Message: {this.message}</p>
          <button onClick={this.changeMessage}>Change Message</button>
        </div>
      </div>
    );
  }
}

export default State;
