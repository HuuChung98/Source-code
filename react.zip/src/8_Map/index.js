import React, { Component } from "react";

class Map extends Component {
  constructor() {
    super();

    this.state = {
      products: [
        { id: 1, name: "Iphone 13 Promax" },
        { id: 2, name: "Samsung S22 Ultra" },
        { id: 3, name: "Xiaomi Mi 12 Pro" },
      ],

      students: [
        { id: "0001", name: "Dan Nguyen", email: "dan@gmail.com" },
        { id: "0002", name: "Khai Truong", email: "khai@gmail.com" },
        { id: "0003", name: "Hieu Dang", email: "hieu@gmail.com" },
      ],
    };
  }

  render() {
    return (
      <div className="container">
        {/* Products */}
        <div className="row">
          {/* Dùng hàm map để duyệt mảng */}
          {this.state.products.map((product, index) => {
            // Duyệt qua mỗi phần tử và return về jsx
            // Mỗi phần tử jsx trong map bắt buộc phải có prop key
            // Giá trị key của mỗi phần từ bắt buộc phải khác nhau
            // Thông thường ta dùng id của data hoặc một số trường hợp có thể dùng index
            return (
              <div key={product.id} className="col-sm-4">
                <div className="card">
                  <div className="card-body">
                    <h4 className="card-title">{product.name}</h4>
                    <button className="btn btn-success">Details</button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Student */}
        <table className="table">
          <thead>
            <tr>
              <th>No.</th>
              <th>Name</th>
              <th>Email</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {this.state.students.map((student, index) => {
              return (
                <tr key={student.id}>
                  <td>{index + 1}</td>
                  <td>{student.name}</td>
                  <td>{student.email}</td>
                  <td>
                    <button className="btn btn-primary">Update</button>
                    <button className="btn btn-danger">Delete</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  }
}

export default Map;
