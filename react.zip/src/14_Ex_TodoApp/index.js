import React, { useState, useEffect } from "react";
import axios from "axios";

import AddTodo from "./AddTodo";
import TodoList from "./TodoList";
import FilterTodo from "./FilterTodo";
import SearchTodo from "./SearchTodo";

const FILTER = {
  all: undefined,
  completed: true,
  uncompleted: false,
};

const TodoApp = () => {
  const [todos, setTodos] = useState([]);
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");

  const fetchTodos = async () => {
    try {
      const { data } = await axios.get(
        "https://625a732843fda1299a17d4e6.mockapi.io/api/todos",
        {
          params: {
            title: search,
            isCompleted: FILTER[filter],
          },
        }
      );
      setTodos(data);
    } catch (error) {
      console.log(error);
    }
  };

  const handleFilter = (filter) => {
    // fetchTodos(filter);
    setFilter(filter);
  };

  const handleSearch = (value) => {
    setSearch(value);
  };

  // useEffect này sẽ được chạy ở lần render đầu tiên, và những lần render sau nếu filter thay đổi
  useEffect(() => {
    // Call API lấy danh sách todos
    fetchTodos();
  }, [filter, search]);

  return (
    <div className="container">
      <div className="row">
        <div className="col-sm-6 mx-auto">
          <h1 className="text-center text-secondary">My Todos</h1>
          <AddTodo onSuccess={fetchTodos} />
          <SearchTodo onSearch={handleSearch} />
          <TodoList todos={todos} onSuccess={fetchTodos} />
          <FilterTodo onFilter={handleFilter} />
        </div>
      </div>
    </div>
  );
};

export default TodoApp;
