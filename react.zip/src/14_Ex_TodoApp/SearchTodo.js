import React, { useRef } from "react";

const SearchTodo = ({ onSearch }) => {
  const timeout = useRef();

  // Kĩ thuật debounce để prevent các hành động gọi API liên tục
  const handleSearch = (evt) => {
    // Trường hợp mà chưa hết 0.3s mà hàm handleSearch đã được gọi lại, ta sẽ clearTimeout để huỷ bỏ callback func trong setTimeout => hàm onSearch sẽ không được gọi tới
    clearTimeout(timeout.current);

    // Khi hàm handleSearch đc gọi, ta tạo setTimeout để delay 0.3s trước khi gọi prop onSearch để call API
    // Gán Timeout lại cho timeout.current để có thể clear timeout
    timeout.current = setTimeout(() => {
      onSearch(evt.target.value);
    }, 300);
  };

  return (
    <div className="form-group">
      <input
        type="text"
        placeholder="Search Todo"
        className="form-control"
        onChange={handleSearch}
      />
    </div>
  );
};

export default SearchTodo;
