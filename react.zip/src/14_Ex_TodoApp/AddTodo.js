import React, { useState } from "react";
import axios from "axios";

const AddTodo = ({ onSuccess }) => {
  const [todo, setTodo] = useState({ title: "", description: "" });

  const handleChange = (evt) => {
    const { name, value } = evt.target;
    setTodo((todo) => ({ ...todo, [name]: value }));
  };

  const handleAddTodo = async () => {
    try {
      await axios.post(
        "https://625a732843fda1299a17d4e6.mockapi.io/api/todos",
        { ...todo, isCompleted: false }
      );
      onSuccess();
      setTodo({ title: "", description: "" });
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="d-flex jutify-content-between align-items-center">
      <div className="d-flex">
        <div className="form-group">
          <label>Title</label>
          <input
            type="text"
            name="title"
            value={todo.title}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label>Description</label>
          <input
            type="text"
            name="description"
            value={todo.description}
            onChange={handleChange}
          />
        </div>
      </div>

      <button className="btn btn-primary" onClick={handleAddTodo}>
        Add
      </button>
    </div>
  );
};

export default AddTodo;
