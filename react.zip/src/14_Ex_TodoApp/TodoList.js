import React from "react";
import cn from "classnames";
import axios from "axios";

import styles from "./styles.module.scss";

const TodoList = ({ todos, onSuccess }) => {
  const handleCompleteTodo = async (todo) => {
    const { id, ...data } = todo;
    try {
      await axios.put(
        `https://625a732843fda1299a17d4e6.mockapi.io/api/todos/${id}`,
        { ...data, isCompleted: true }
      );
      onSuccess();
    } catch (error) {
      console.log(error);
    }
  };

  const handleDeleteTodo = async (id) => {
    try {
      await axios.delete(
        `https://625a732843fda1299a17d4e6.mockapi.io/api/todos/${id}`
      );
      onSuccess();
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <ul className="p-0">
      {todos.map((todo) => {
        return (
          <li className="d-flex justify-content-between align-items-center mb-4">
            <div
              className={cn("d-flex flex-column", {
                [styles.todoCompleted]: todo.isCompleted,
              })}
            >
              <span>{todo.title}</span>
              <i>{todo.description}</i>
            </div>

            <div>
              <button
                className={cn("btn btn-success mr-2", {
                  [styles.btnCompleted]: todo.isCompleted,
                })}
                onClick={() => handleCompleteTodo(todo)}
              >
                Complete
              </button>
              <button
                className="btn btn-danger"
                onClick={() => handleDeleteTodo(todo.id)}
              >
                Delete
              </button>
            </div>
          </li>
        );
      })}
    </ul>
  );
};

export default TodoList;
