import React from "react";

const FilterTodo = ({ onFilter }) => {
  return (
    <div>
      <button className="btn btn-primary mr-2" onClick={() => onFilter("all")}>
        All
      </button>
      <button
        className="btn btn-success mr-2"
        onClick={() => onFilter("completed")}
      >
        Completed
      </button>
      <button
        className="btn btn-warning"
        onClick={() => onFilter("uncompleted")}
      >
        Uncompleted
      </button>
    </div>
  );
};

export default FilterTodo;
