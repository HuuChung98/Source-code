// Snippet để tạo component: a-component, a-component-inline
import { Component, OnInit } from '@angular/core';
import { CurrentUser } from '../core/models/user.interface';
import { AuthService } from '../core/services/auth.service';

@Component({
  selector: 'app-welcome',
  // templateUrl: './welcome.component.html',
  // styleUrls: ['./welcome.component.scss'],
  template: `
    <h1 class="title">Welcome to BC19</h1>
    <h3>Họ Tên: {{ currentUser?.hoTen }}</h3>
    <h3>Email: {{ currentUser?.email }}</h3>
  `,
  styles: [
    `
      .title {
        color: blue;
      }
    `,
  ],
})
export class WelcomeComponent implements OnInit {
  currentUser?: CurrentUser;
  constructor(private authService: AuthService) {}

  ngOnInit() {
    this.authService.currentUser.subscribe({
      next: (value) => {
        this.currentUser = value;
      },
    });
  }
}








