import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkout',
  template: ``,
})
export class ExCheckoutComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
