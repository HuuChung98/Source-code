export interface CurrentUser {
  taiKhoan: string;
  email: string;
  hoTen: string;
  soDt: string;
  maLoaiNguoiDung: string;
  maNhom: string;
  accessToken: string;
}
