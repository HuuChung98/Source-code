import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { CurrentUser } from '../models/user.interface';

@Injectable({ providedIn: 'root' })
export class AuthService {
  currentUser = new BehaviorSubject<CurrentUser>({} as CurrentUser);
  // this.currentUser.next(value): dùng để cập nhật value cho currentUser
  // this.currentUser.value: dùng để lấy ra value hiện tại của currentUser
  // this.currentUser.subscribe({next, error, complete}): dùng để nhận được data tương ứng khi currentUser được cập nhật

  constructor(private http: HttpClient) {
    const user = JSON.parse(localStorage.getItem('user') as string);
    if (user) {
      this.currentUser.next(user);
    }
  }

  login(values: any): Observable<any> {
    return this.http.post<any>('QuanLyNguoiDung/DangNhap', values);
  }

  register(values: any): Observable<any> {
    return this.http.post<any>('QuanLyNguoiDung/DangKy', {
      ...values,
      maNhom: 'GP01',
    });
  }
}
