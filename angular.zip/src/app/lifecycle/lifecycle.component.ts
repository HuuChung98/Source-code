import {
  Component,
  Input,
  OnInit,
  OnChanges,
  AfterViewInit,
  OnDestroy,
  SimpleChanges,
} from '@angular/core';
import { Subscription } from 'rxjs';
import { AuthService } from '../core/services/auth.service';

@Component({
  selector: 'app-lifecycle',
  template: ``,
})
export class LifeCycleComponent
  implements OnInit, OnChanges, AfterViewInit, OnDestroy
{
  @Input() data: any[] = [];
  @Input() message: string = '';

  subscription = new Subscription();

  // Phương thức mặc định được thực thi component khởi tạo
  // Thường dùng để khai báo depedency injection (khai báo sử dụng các services)
  constructor(private authService: AuthService) {}

  // Được chạy thứ 2 sau constructor
  // Phương thức này chỉ thực thi nếu component có Input và được thực thi mỗi khi giá trị của các Input thay đổi
  // Input có type là Array/Object thì khi thay đổi 1 property hoặc push một phần tử vào mảng, thì ngOnChange sẽ không chạy, trường hợp này ta cần thay đổi reference của biến Input (sử dụng spread operator)
  ngOnChanges(changes: SimpleChanges): void {
    const { data } = changes;
    if (data.previousValue !== data.currentValue) {
      // do something
    }
  }

  // Được chạy thứ 3 sau ngOnChanges
  // Phương thức được thực thi duy nhất một lần khi khởi tạo xong component, thường dùng để subscribe các Observable (API, global varables)
  ngOnInit() {
    this.subscription.add(
      this.authService.currentUser.subscribe({
        next: (value) => {
          console.log(value);
        },
      })
    );
  }

  // Được thực thi sau khi angular đã hoàn thành khởi tạo view component, và nó chỉ được chạy duy nhất 1 lần
  // Tương tác với DOM (ViewChild, ViewChildren)
  ngAfterViewInit(): void {}

  // Được thực thi một lần duy nhất trước khi component bị huỷ, thường được dùng để xử lý remove các event, unsubscribe observable
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
