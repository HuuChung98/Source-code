Project structure

- src

  - components

    - Là những component nhận vào props và render UI, được sử dụng ở nhiều nơi trong ứng dụng
    - Thường sẽ không có xử lý logic ở những component này
    - Button, Card, Modal, Header, Text,...

  - modules

    - Nơi chứa những component chính cho ứng dụng, sẽ có những xử lý logic như call API, xử lý nghiệp vụ
    - Có thể là 1 page, hoặc tập hợp một nhóm các chức năng

    * Home (module)
      - components: Chỉ chứa các component được sử dụng trực tiếp bên trong chính module này, những component này có thể chứa các tác vụ logic như call API,...
      - pages: Component sẽ kết nối trực tiếp với router

  - apis/services
    - Setup thư viện gọi API (axios)
    - Định nghĩa các function gọi API
