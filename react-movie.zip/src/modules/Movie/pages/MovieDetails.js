import React, { useEffect } from "react";
import { useParams } from "react-router-dom";

const MovieDetails = () => {
  const { movieId } = useParams();

  useEffect(() => {
    // Dùng movieId để dispatch action lấy chi tiết phim
    // dispatch(getMovieDetails(movieId))
    console.log(movieId);
  }, []);

  return <div>MovieDetails</div>;
};

export default MovieDetails;
