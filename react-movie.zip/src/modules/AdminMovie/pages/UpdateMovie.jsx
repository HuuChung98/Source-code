import React from "react";

const UpdateMovie = () => {
  return <div>UpdateMovie</div>;
};

export default UpdateMovie;
