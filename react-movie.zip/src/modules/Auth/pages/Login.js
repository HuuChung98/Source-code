import React from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { Navigate } from "react-router-dom";
import { login } from "../slices/authSlice";

const Login = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    defaultValues: {
      taiKhoan: "",
      matKhau: "",
    },
    // mode mặc định là onSubmit
    // Quyết định khi nào sẽ kích hoạt validation
    mode: "onTouched",
  });

  const dispatch = useDispatch();
  const { user, isLoading, error } = useSelector((state) => state.auth);

  const onSubmit = (values) => {
    console.log(values);
    dispatch(login(values));
  };

  const onError = (error) => {
    console.log(error);
  };

  if (user) {
    // Sau khi đăng nhập thành công
    // Redirect user về trang Home

    if (user.maLoaiNguoiDung === "QuanTri") {
      return <Navigate to="/admin/movies" />;
    }

    return <Navigate to="/" />;
  }

  return (
    <div>
      <h1>Login</h1>

      <form onSubmit={handleSubmit(onSubmit, onError)}>
        <div>
          <label>Tài khoản</label>
          <input
            type="text"
            {...register("taiKhoan", {
              required: {
                value: true,
                message: "Tài khoản không được để trống",
              },
              minLength: {
                value: 5,
                message: "Tài khoản phải từ 5 đến 20 kí tự",
              },
              maxLength: {
                value: 20,
                message: "Tài khoản phải từ 5 đến 20 kí tự",
              },
            })}
          />
          {errors.taiKhoan && <span>{errors.taiKhoan.message}</span>}
        </div>

        <div>
          <label>Mật khẩu</label>
          <input
            type="password"
            {...register("matKhau", {
              required: {
                value: true,
                message: "Mật khẩu không được để trống",
              },
              pattern: {
                value: /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/,
                message: "Mật khẩu không đúng định dạng",
              },
            })}
          />
          {errors.matKhau && <span>{errors.matKhau.message}</span>}
        </div>

        <button disabled={isLoading}>Đăng Nhập</button>
        {error && <p>{error}</p>}
      </form>
    </div>
  );
};

export default Login;
