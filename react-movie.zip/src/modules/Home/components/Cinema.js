import React from 'react'

const Cinema = () => {
  return (
    <div>Cinema</div>
  )
}

export default Cinema