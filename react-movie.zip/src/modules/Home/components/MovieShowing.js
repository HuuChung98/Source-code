import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";

import { getMovieShowing } from "../slices/movieShowingSlice";

const MovieShowing = () => {
  const { data, isLoading, error } = useSelector((state) => state.movieShowing);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  useEffect(() => {
    dispatch(getMovieShowing());
  }, []);

  return (
    <div>
      {data.map((movie) => {
        return (
          <p key={movie.maPhim}>
            <Typography variant="body1" component="span">
              {movie.tenPhim}
            </Typography>
            <Button
              variant="contained"
              color="success"
              onClick={() => navigate(`/movies/${movie.maPhim}`)}
            >
              Details
            </Button>
          </p>
        );
      })}
    </div>
  );
};

export default MovieShowing;
