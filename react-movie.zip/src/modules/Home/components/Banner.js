import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { getBanners } from "../slices/bannerSlice";

const Banner = () => {
  const { data, isLoading, error } = useSelector((state) => state.banner);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getBanners());
  }, []);

  console.log(data);
  return <div>Banner</div>;
};

export default Banner;
